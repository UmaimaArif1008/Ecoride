class JSONResponse:
     StatusCode: int
     Message: str
     #Object: {}


class JSONResponseObject:
     StatusCode: int
     Message: str
     Object: object



